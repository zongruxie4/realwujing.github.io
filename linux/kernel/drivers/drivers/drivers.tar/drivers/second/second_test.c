#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/stat.h>

main()
{
  int fd;
  int counter = 0;
  int old_counter = 0;
  
  /*��/dev/second�豸�ļ�*/
  fd = open("/dev/second", O_RDONLY);
  if (fd != - 1) {
    while (1) {
      read(fd,&counter, sizeof(unsigned int));/* ��Ŀǰ���������� */
      if(counter!=old_counter) {	
      	printf("seconds after open /dev/second :%d\n",counter);
      	old_counter = counter;
      }	
    }    
  } else {
    printf("Device open failure\n");
  }
}
