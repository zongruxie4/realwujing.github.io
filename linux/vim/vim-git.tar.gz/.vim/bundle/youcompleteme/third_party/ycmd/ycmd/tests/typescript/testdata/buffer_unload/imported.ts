export class Imported {
    method() {
    }
}
